### Git入门操作

## 1、安装git

默认配置安装就好。。。

## 2、git操作

#### 一、clone Github上已存在的Repository

可以通过以下命令，clone在github上存在的代码仓库

```json
git clone git@youremail.example.com
```

#### 二、创建远程仓库

###### 1、注册并登陆git

###### 2、创建SSH Key

本地git仓库和github仓库之间的传输是通过SSH加密的，所以需要提前设置。首先，看看用户目录下是否有**.ssh** 文件，里面包含了id_rsa和id_rsa.pub这两个文件，如果没有的话，使用一下明令创建密钥：

```js
ssh-keygen -t rsa –C “youremail@example.com”

//注意email地址是自己的地址
```

###### 3、添加 SSH Key

登录github，在右上角找到setting，添加SSH Keys页面，然后点击“ADDSSHKey”，其中title选项可以任意填写，key文本，填写本机.ssh文件中的id_rsa.pub中的内容，点击Add key就可以添加key了。

![git-key内容](D:\workspace\md\git操作\git-key内容.png)

![git-SSH Key添加](D:\workspace\md\git操作\git-SSH Key添加.png)



###### 4、添加远程仓库

在右上角+符号处，添加新的repository。

![建立branch](D:\workspace\md\git操作\建立branch.png)

远程仓库设置：

![git-新的远程仓库](D:\workspace\md\git操作\git-新的远程仓库.png)

new repository建立完成

![连接远程仓库](D:\workspace\md\git操作\连接远程仓库.png)

使用指导明令连接本地仓库

```js
git remote add origin https://github.com/Sky-walker-only/iviewTrunk.git
git push -u origin master
```



#### 三、创建本地git分支

###### 1、git bash

git安装完成之后，使用Git Bash（git的明令行工具）进入命令工具：

![git-bash](D:\workspace\md\git操作\git-bash.png)

###### 2、选定本地仓库目录位置

进入指定目录：

```js
cd workspace/gittrunk/iviewTrunk
```

![git-选定指定目录仓库](D:\workspace\md\git操作\git-选定指定目录仓库.png)

###### 3、连接远程仓库

建立版本库（一个.git文件，包含相关信息）并连接远程仓库提交

选定指定目录之后，可以参考远程仓库创建的第四步，git提供的指引明令：

```js
git init	//添加版本库
git add README.md		//添加文件
git commit -m "first commit"		//提交文件
git remote add origin https://github.com/Sky-walker-only/iviewTrunk.git		//连接远程库
git push -u origin master		//推送到远程仓库
```



到此，我们已经将本地的git仓库和远程github连接在一起，以后的项目可以通过下面的明令，将本地代码更新到远程仓库。

```
git push -u origin master
```

#### 四、git常见明令

创建本地分支

```js
git branch [branch name]		//创建分支
git checkout [branch name]		//切换到新的分支
git checkout -b [branch name]	//创建分支的同时切换到该分支
git branch -d [branch name]		//删除本地分支
git push origin :[branch name]	//删除github远程分支
git status 			//查看提交状态
```

